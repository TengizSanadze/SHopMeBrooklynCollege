package com.shopme.admin.brand;

public class BrandNotFoundException extends Exception {

	public BrandNotFoundException(String message) {
		super(message);
	}

}
