package com.shopme.common.entity.setting;

public enum SettingCategory {
	GENERAL, MAIL_SERVER, MAIL_TEMPLATES, CURRENCY, PAYMENT
}
